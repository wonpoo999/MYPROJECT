package com.example.health_dietcare.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.health_dietcare.dto.AuthDtos;
import com.example.health_dietcare.repository.UserRepository;
import com.example.health_dietcare.service.AuthService;

import java.util.LinkedHashMap;
import java.util.Map;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthService auth;
    private final UserRepository users;

    // 중복 체크: 예외 발생시에도 200으로 내려주어 프론트 UX를 지키고, 공백/널은 false 처리
    @GetMapping("/exists")
    public AuthDtos.ExistsRes exists(@RequestParam String username){
        String u = username == null ? "" : username.trim();
        boolean exists = false;
        try {
            if (!u.isEmpty()) {
                // 대소문자 무시하고 안전하게 확인 (JPQL 메서드)
                exists = users.existsUsernameIgnoreCase(u);
            }
        } catch (Exception e) {
            log.warn("exists check failed for '{}': {}", u, e.getMessage());
        }
        return new AuthDtos.ExistsRes(exists);
    }

    // 주소창(GET)으로 접근 시 사용법 안내 (200)
    @GetMapping("/register")
    public Map<String, Object> registerHelp() {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("username", "alice");
        body.put("password", "P@ssw0rd!");
        body.put("passwordCheck", "P@ssw0rd!");
        body.put("email", "alice@example.com");
        body.put("emailCheck", "alice@example.com");
        body.put("name", "Alice");
        body.put("gender", "FEMALE");
        body.put("heightCm", 165);
        body.put("weightKg", 55.5);
        body.put("bornTown", "Seoul");
        body.put("livedTown", "Busan");
        body.put("motherName", "Kim");
        body.put("dogName", "Bori");
        body.put("elementary", "ABC");
        body.put("publicProfile", true);

        Map<String, Object> out = new LinkedHashMap<>();
        out.put("hint", "POST /api/auth/register 로 JSON 바디를 보내세요");
        out.put("body.example", body);
        return out;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody AuthDtos.RegisterReq r){
        auth.register(r);
        return ResponseEntity.ok().build();
    }

    // 주소창(GET)으로 접근 시 사용법 안내 (200)
    @GetMapping("/login")
    public Map<String, Object> loginHelp() {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("username", "alice");
        body.put("password", "P@ssw0rd!");

        Map<String, Object> out = new LinkedHashMap<>();
        out.put("hint", "POST /api/auth/login 로 JSON 바디를 보내세요");
        out.put("body.example", body);
        return out;
    }

    @PostMapping("/login")
    public AuthDtos.LoginRes login(@RequestBody AuthDtos.LoginReq r){
        return auth.login(r);
    }
}
