package com.example.health_dietcare.entity;
public enum Gender { MALE, FEMALE, OTHER }
