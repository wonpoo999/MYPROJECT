package com.example.health_dietcare.entity;
public enum MembershipTier { FREE, PREMIUM }
