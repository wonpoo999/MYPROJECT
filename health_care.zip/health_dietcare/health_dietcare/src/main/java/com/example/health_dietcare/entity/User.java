package com.example.health_dietcare.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "users", indexes = {
        @Index(name = "ux_users_username", columnList = "username", unique = true),
        @Index(name = "ux_users_email", columnList = "email", unique = true)
})
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString(exclude = "password") // 비밀번호 로그 노출 방지
public class User {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** 로그인 아이디 */
    @Column(nullable = false, unique = true, length = 100)
    private String username;

    /** 이메일 */
    @Column(nullable = false, unique = true, length = 190)
    private String email;

    /** BCrypt 등으로 해시된 비밀번호를 저장 (필드명은 password로 유지) */
    @Column(nullable = false, length = 255)
    private String password;

    /** 표시명 */
    @Column(nullable = false, length = 100)
    private String name;

    /** 권한 */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Role role;

    /** 성별 */
    @Enumerated(EnumType.STRING)
    @Column(length = 10)
    private Gender gender;

    private Integer heightCm;
    private Double  weightKg;

    @Column(nullable = false)
    private boolean publicProfile;

    /** 요금제/등급 */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Tier tier;

    public enum Role   { USER, ADMIN }
    public enum Gender { MALE, FEMALE, OTHER }
    public enum Tier   { FREE, PRO, PREMIUM }

    /** null 로 들어오는 필드들에 대한 안전한 기본값 */
    @PrePersist
    public void prePersistDefaults() {
        if (role == null) role = Role.USER;
        if (gender == null) gender = Gender.OTHER;
        if (tier == null) tier = Tier.FREE;
        // Boolean/primitive 기본값
        publicProfile = (publicProfile); // primitive라 null 아님, 필요시 true 기본 원하면 아래처럼:
        // publicProfile = true;
    }
}
