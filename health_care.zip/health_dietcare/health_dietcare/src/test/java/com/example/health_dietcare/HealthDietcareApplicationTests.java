package com.example.health_dietcare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthDietcareApplicationTests {

	@Test
	void contextLoads() {
	}

}
